select tag_name, count(tag_id) from tags inner join photo_tags on 
tags.id=photo_tags.tag_id group by tags.id order by count(tags.id) desc limit 5;

select users.username, count(photos.id) as photo_count from users join photos on
users.id=photos.id group by users.id;

select distinct users.username, users.id from users where not exists(select 
photos.id from photos where not exists(select likes.user_id from likes where
likes.user_id=users.id and likes.photo_id=photos.id));

select users.id, users.username, rank() over(order by created_at)
as rank_account_creation from users;

select photos.id, count(comments.id), comments.comment_text, photos.image_url,
users.username from comments join photos on comments.id=photos.id 
join users on photos.id=users.id group by photos.id;

select tag_name, count(photo_id), rank() over(order by count(photo_id) desc)
as photo_rank from tags join photo_tags on tags.id=photo_tags.photo_id group by
tags.id;

select username, count(photos.id),
rank() over(order by count(photos.id) desc) as photo_rank from users inner join 
photos on users.id=photos.id group by users.id;

select username, photos.created_at,
lead(photos.created_at) over(order by created_at) as next_photo from users
inner join photos on users.id=photos.id;

select comments.comment_text, users.username,
lag(comment_text) over(order by comments.photo_id) as previous_comment from 
comments join users on comments.id=users.id;

select users.username, count(photos.id),
lag(count(photos.id)) over(order by users.created_at) as photos_before,
lead(count(photos.id)) over(order by users.created_at) as photos_after from 
users join photos on users.id=photos.user_id group by users.id
order by users.created_at;


